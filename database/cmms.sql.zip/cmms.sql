-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2020 at 12:27 AM
-- Server version: 5.6.37
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cmms`
--

-- --------------------------------------------------------

--
-- Table structure for table `calibration`
--

CREATE TABLE IF NOT EXISTS `calibration` (
  `department` varchar(200) NOT NULL,
  `dcode` int(100) NOT NULL,
  `nomenclature` varchar(200) NOT NULL,
  `cal_id` varchar(200) NOT NULL,
  `time_period` varchar(200) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `assigned_to` varchar(200) NOT NULL,
  `calibration_task` varchar(200) NOT NULL,
  `contract_id` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `calibration`
--

INSERT INTO `calibration` (`department`, `dcode`, `nomenclature`, `cal_id`, `time_period`, `from_date`, `to_date`, `assigned_to`, `calibration_task`, `contract_id`, `status`) VALUES
('ICU', 100, 'Ultrasound Unit', 'icu01ultras', '2 days', '2020-04-02', '2020-04-04', 'mohamed ahmed', 'propes defect', '309031', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `daily_inspection`
--

CREATE TABLE IF NOT EXISTS `daily_inspection` (
  `nomenclature` varchar(200) NOT NULL,
  `dinspect_id` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `d_code` int(100) NOT NULL,
  `physical_condition` varchar(200) NOT NULL,
  `batteries` varchar(200) NOT NULL,
  `cables_port` varchar(200) NOT NULL,
  `self_test` varchar(200) NOT NULL,
  `tech_name` varchar(200) NOT NULL,
  `inspection_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `daily_inspection`
--

INSERT INTO `daily_inspection` (`nomenclature`, `dinspect_id`, `department`, `d_code`, `physical_condition`, `batteries`, `cables_port`, `self_test`, `tech_name`, `inspection_date`, `comment`) VALUES
('Ultrasound Unit', 'icu01ultras', 'ICU', 100, 'Y', 'Y', 'Y', 'Y', 'mohamed ahmed', '2020-04-25 23:02:13', 'alright');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `name` varchar(200) NOT NULL,
  `floor` varchar(200) NOT NULL,
  `building` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `b_id` int(100) NOT NULL,
  `code` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`name`, `floor`, `building`, `location`, `b_id`, `code`) VALUES
('ICU', '4', '1', '1st branch', 1, 100),
('ICU', '3', '1', '1st branch', 2, 101),
('ICU', '3', '1', '2nd branch', 1, 102),
('OP', '1', '1', '1st branch', 1, 150),
('OP', '1', '1', '2nd branch', 1, 151),
('biomedical engineering', 'P1', '1', '1st branch', 1, 160),
('biomedical engineering', 'P1', '1', '2nd branch', 1, 161),
('ER', '1', '1', '1st branch', 1, 200),
('ER', '1', '1', '2nd branch', 1, 201),
('IP', '2', '1', '1st branch', 1, 250),
('IP', '2', '1', '2nd branch', 1, 251),
('Radiology', '1', '1', '1st branch', 1, 400),
('Radiology', '1', '1', '2nd branch', 1, 401),
('OR', '3', '1', '1st branch', 1, 450),
('OR', '3', '1', '2nd branch', 1, 451),
('Anesthesiology', '3', '1', '1st branch', 1, 500),
('Anesthesiology', '3', '1', '2nd branch', 1, 501),
('Cardiology', '2', '1', '1st branch', 1, 550),
('Cardiology', '2', '1', '2nd branch', 1, 551),
('CSSD', 'P1', '1', '1st branch', 1, 600),
('CSSD', 'P1', '1', '2nd branch', 1, 601),
('OBGYN', '1', '1', '1st branch', 1, 700),
('OBGYN', '1', '1', '2nd branch', 1, 701),
('Laboratory', '4', '1', '1st branch', 1, 750),
('Laboratory', '4', '1', '2nd branch', 1, 751),
('Neurology', '4', '1', '1st branch', 1, 800),
('Neurology', '4', '1', '2nd branch', 1, 801),
('Oncology', '4', '1', '1st branch', 1, 850),
('Oncology', '4', '1', '2nd branch', 1, 851),
('Orthopedics', '1', '1', '1st branch', 1, 880),
('Orthopedics', '1', '1', '2nd branch', 1, 881),
('Otolaryngology ', '4', '1', '1st branch', 1, 920),
('Otolaryngology ', '4', '1', '2nd branch', 1, 921),
('Urology', '4', '1', '1st branch', 1, 950),
('Urology', '4', '1', '2nd branch', 1, 951);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `name` varchar(200) NOT NULL,
  `national_id` bigint(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile_no` int(100) NOT NULL,
  `role` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `depart_code` int(11) NOT NULL,
  `qualifications` varchar(200) NOT NULL,
  `salary` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`name`, `national_id`, `email`, `mobile_no`, `role`, `position`, `department`, `depart_code`, `qualifications`, `salary`) VALUES
('mohamed ahmed', 280040122104028, 'mohamedahmed@gmail.com', 1133536373, 'Engineer', 'Junior', 'biomedical engineering', 160, 'bachelor in biomedical engineering CUFE ', 5000),
('maher mohamed', 290050122104028, 'maher_mohamed@gmail.com', 1037897879, 'technician', 'junior', 'biomedical engineering', 160, 'institution of electronics', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE IF NOT EXISTS `equipment` (
  `department` varchar(200) NOT NULL,
  `dep_code` int(100) NOT NULL,
  `nomenclature` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `id` varchar(200) NOT NULL,
  `model` varchar(200) NOT NULL,
  `manufacturer` varchar(200) NOT NULL,
  `contact_manufacturer` varchar(200) DEFAULT NULL,
  `local_agent` varchar(200) CHARACTER SET utf8mb4 NOT NULL,
  `contact_agent` varchar(200) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  `condition_code` varchar(100) NOT NULL,
  `price` varchar(200) NOT NULL,
  `install_date` date NOT NULL,
  `warrenty_period` date DEFAULT NULL,
  `maintenance_assessment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`department`, `dep_code`, `nomenclature`, `serial_no`, `id`, `model`, `manufacturer`, `contact_manufacturer`, `local_agent`, `contact_agent`, `condition_code`, `price`, `install_date`, `warrenty_period`, `maintenance_assessment`) VALUES
('IP', 250, 'PATIENT-BED', '0150BB0', 'M01BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0155BB5', 'M02BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0160BB10', 'M03BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0165BB15', 'M04BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'Patient-BED', '0170BB20', 'M05BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0175BB25', 'M06BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0180BB30', 'M07BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0185BB35', 'M08BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0190BB40', 'M09BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('IP', 250, 'PATIENT-BED', '0195BB45', 'M10BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'Alcan Medical', 'NULL', 'A', '12000', '2017-04-15', '2020-04-15', 'N'),
('ICU', 100, 'ULTRASOUND-UNIT', '050415VS1N', 'ICU01US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-07-14', NULL, 'Y'),
('ICU', 100, 'ULTRASOUND-UNIT', '050415VS2N', 'ICU02US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-07-14', NULL, 'Y'),
('ICU', 101, 'ULTRASOUND-UNIT', '050415VS3N', 'ICU03US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-07-14', NULL, 'Y'),
('ICU', 101, 'ULTRASOUND-UNIT', '050415VS4N', 'ICU04US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-07-14', NULL, 'Y'),
('ICU', 100, 'ULTRASOUND-UNIT', '050415VS5N', 'icu01ultras', 'Vivid S5', 'GE', 'NULL', 'Alcan Medical', 'NULL', 'A', '$13,000', '2017-10-04', '2021-08-19', 'Y'),
('ICU', 102, 'ULTRASOUND-UNIT', '050415VS7W', 'ICU11US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-12-09', NULL, 'Y'),
('ICU', 102, 'ULTRASOUND-UNIT', '050415VS8W', 'ICU12US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-12-09', NULL, 'Y'),
('ICU', 102, 'ULTRASOUND-UNIT', '050415VS9W', 'ICU13US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'A', '250000', '2019-12-09', NULL, 'Y'),
('OP', 150, 'ULTRASOUND-UNIT', '069315VL2O', 'OP501US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'B', '252400', '2020-02-09', NULL, 'Y'),
('OP', 150, 'ULTRASOUND-UNIT', '069315VL3O', 'OP502US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'B', '252400', '2020-02-09', NULL, 'Y'),
('OP', 151, 'ULTRASOUND-UNIT', '069315VL4O', 'OP511US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'B', '252400', '2020-02-09', NULL, 'Y'),
('OP', 151, 'ULTRASOUND-UNIT', '069315VL5O', 'OP512US', 'EPIQ-5', 'PHILIPS', NULL, 'ELFATH', NULL, 'B', '252400', '2020-02-09', NULL, 'Y'),
('IP', 251, 'BLOOD-GLUCOMETER', '10011LGB605', 'M07GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2018-02-14', '2021-02-14', 'N'),
('IP', 251, 'BLOOD-GLUCOMETER', '10013LGB607', 'M08GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2018-02-14', '2021-02-14', 'N'),
('IP', 251, 'BLOOD-GLUCOMETER', '10015LGB609', 'M09GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2018-02-14', '2021-02-14', 'N'),
('IP', 251, 'BLOOD-GLUCOMETER', '10017LGB611', 'M10GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2018-02-14', '2021-02-14', 'N'),
('IP', 250, 'BLOODGLUCOMETER', '1002LGB500', 'M01GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2017-01-14', '2021-01-14', 'N'),
('IP', 250, 'BLOODGLUCOMETERS', '1003LGB300\r\n', 'M02GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '400', '2017-01-14', '2021-01-14', 'N'),
('IP', 250, 'BLOODGLUCOMETER', '1004LGB200', 'M03GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ALFATH', 'NULL', 'A', '480', '2017-01-14', '2021-01-14', 'N'),
('IP', 250, 'BLOODGLUCOMETER', '1005LGB100', 'M04GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2017-01-14', '2021-01-14', 'N'),
('IP', 250, 'BLOODGLUCOMETER', '1006LGB400', 'M05GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2017-01-14', '2021-01-14', 'N'),
('IP', 251, 'BLOOD-GLUCOMETER', '1009LGB602', 'M06GLU-IP', 'CEISO15197ISO13485', 'SEJOY', 'NULL', 'ELFATH', 'NULL', 'A', '480', '2018-02-14', '2021-02-14', 'N'),
('IP', 251, 'PATIENT-BED', '1151BB0', 'M11BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1155BB5', 'M12BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1160BB10', 'M13BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1165BB15', 'M14BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1170BB20', 'M15BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1175BB25', 'M16BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1180BB30', 'M17BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1185BB35', 'M18BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1190BB40', 'M19BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('IP', 251, 'PATIENT-BED', '1195BB45', 'M20BED-IP', 'EUCLIDE45', 'ANTANTO', 'NULL', 'ALCAN MEDICAL', 'NULL', 'A', '\r\n12500', '2018-03-15', '2021-03-15', 'N'),
('ICU', 102, 'INFUSION-PUMP', '18VUTT95', 'ICU11IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6700', '2020-04-12', NULL, 'N'),
('ICU', 100, 'INFUSION-PUMP', '191UTT70', 'ICU01IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6000', '2019-11-12', NULL, 'Y'),
('Otolaryngology', 920, 'ELECTROMAGNETIC SURGICAL NAVIGATION SYSTEM', '196H3F4', 'M01ELECTROSURG-OTO', 'FUSION™ ENT', 'Medtronic', NULL, 'Alcan medical', NULL, 'A', '200000', '2017-06-15', '2021-06-15', 'Y'),
('Urology', 950, 'PROSTATE BIOPSY NEEDLE ', '22D3', 'M01PROSNEEDLE-URO', 'BIOPSY GUN', 'Amecath', NULL, 'ElFATH', NULL, 'A', '$100', '2016-01-20', NULL, 'N'),
('Urology', 951, 'PROSTATE BIOPSY NEEDLE ', '22D6', 'M02PROSNEEDLE-URO', 'BIOPSY GUN', 'Amecath', NULL, 'ElFATH', NULL, 'A', '$100', '2016-01-20', NULL, 'N'),
('Otolaryngology', 920, 'ENT WORKSTATION', '234efs5', 'M01ENTWS-OTO', 'OTONAM 200', 'NAMROL ', NULL, 'Alcan medical', NULL, 'A', '71000', '2019-08-05', '2024-08-05', 'Y'),
('Otolaryngology', 921, 'ENT WORKSTATION', '244efs5', 'M03ENTWS-OTO', 'OTONAM 200', 'NAMROL ', NULL, 'Alcan medical', NULL, 'A', '71000', '2019-08-05', '2024-08-05', 'Y'),
('Urology', 950, 'Urological Table,Exam', '2536hd632', 'M01TAB-URO', 'CFUR301', 'OAKWORKS', NULL, 'Alcan Medical', NULL, 'A', '$30000', '2018-03-08', '2024-03-08', 'Y'),
('Urology', 951, 'Urological Table,Exam', '2536hd634', 'M02TAB-URO', 'CFUR301', 'OAKWORKS', NULL, 'Alcan Medical', NULL, 'A', '$30000', '2018-06-15', '2024-06-15', 'Y'),
('ICU', 102, 'INFUSION-PUMP', '28VUTT95', 'ICU12IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6700', '2020-04-12', NULL, 'N'),
('ICU', 100, 'INFUSION-PUMP', '291UTT70', 'ICU02IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6000', '2019-11-12', NULL, 'Y'),
('Urology', 950, 'UTERINE MORCELLATOR', '2ER4FD3', 'M01MORC-URO', 'POWERDRIVE MACRO', 'WISAP Medical Technology ', NULL, 'ELFATH', NULL, 'A', '20000', '2017-10-30', '2020-10-30', 'N'),
('Urology', 951, 'UTERINE MORCELLATOR', '2ER9FD6', 'M02MORC-URO', 'POWERDRIVE MACRO', 'WISAP Medical Technology ', NULL, 'ELFATH', NULL, 'A', '20000', '2017-10-30', '2020-10-30', 'N'),
('Laboratory', 750, 'ORBITAL THERMO-MIXER', '2S3F2W12', 'M01MIXER-LAB', 'TSC', 'analyticajena', NULL, 'EGA-TECH', NULL, 'A', '7000', '2017-11-10', '2020-11-10', 'N'),
('Laboratory', 751, 'ORBITAL THERMO-MIXER', '2S3F2W33', 'M02MIXER-LAB', 'TSC', 'analyticajena', NULL, 'EGA-TECH', NULL, 'A', '7500', '2018-11-20', '2021-11-20', 'N'),
('Urology', 950, 'UROLOGICAL SURGERY LASER', '3234f5g3', 'M01LASER-URO', 'MEDILAS® H UROPULSE®\r\n', 'Dornier MedTech', NULL, 'Alcan medical', NULL, 'A', '300000', '2019-08-11', '2024-08-11', 'Y'),
('Urology', 951, 'UROLOGY FORCEPS  ', '323f222w2', 'M02FORC-URO', '61002X SERIES', 'ENDOMED', NULL, 'ELFATH', NULL, 'A', '8000', '2019-03-25', NULL, 'N'),
('Urology', 950, 'UROLOGY FORCEPS ', '323f342w2', 'M01FORC-URO', '61002X SERIES', 'ENDOMED', NULL, 'ELFATH', NULL, 'A', '8000', '2019-03-25', NULL, 'N'),
('Urology', 951, 'UROLOGICAL SURGERY LASER', '3255f5g3', 'M02LASER-URO', 'MEDILAS® H UROPULSE®\r\n', 'Dornier MedTech', NULL, 'Alcan medical', NULL, 'A', '300000', '2019-08-11', '2024-08-11', 'Y'),
('Urology', 951, 'PORTABLE BLADDER SCANNER,WITH TROLLEY', '345T644S2', 'M02BLASCAN-URO', 'PORTASCAN 3D', 'LABORIE', NULL, 'ELFATH', NULL, 'A', '$50000', '2010-11-02', '2015-11-02', 'N'),
('Urology', 950, 'PORTABLE BLADDER SCANNER,WITH TROLLEY ', '345T67SS2', 'M01BLASCAN-URO', 'PORTASCAN 3D', 'LABORIE', NULL, 'ELFATH', NULL, 'A', '$50000', '2010-11-02', '2015-11-02', 'N'),
('Urology', 950, 'KIDNEY STONE EXTRACTION ENDOSCOPIC BASKET', '34S3', 'M01STONEENDO-URO', 'SBS', 'MEDpro', NULL, 'ELFATH', NULL, 'A', '3000', '2018-05-20', NULL, 'N'),
('Laboratory', 751, 'LABORATORY DRYING OVEN,HYBRIDIZATION ,BENCHTOP', '35G33', 'M02DRYOVE-LAB', 'OV 4000', 'Analytikajena', NULL, 'EGA-TECH', NULL, 'A', '40000', '2018-03-10', '2021-03-10', 'Y'),
('Laboratory', 750, 'LABORATORY DRYING OVEN,HYBRIDIZATION ,BENCHTOP', '35GS52', 'M01DRYOVE-LAB', 'OV 4000', 'Analytikajena', NULL, 'EGA-TECH', NULL, 'A', '40000', '2018-03-10', '2021-03-10', 'Y'),
('ICU', 102, 'INFUSION-PUMP', '38VUTT95', 'ICU13IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6700', '2020-04-12', NULL, 'N'),
('ICU', 100, 'INFUSION-PUMP', '391UTT70', 'ICU03IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6000', '2019-11-12', NULL, 'Y'),
('Urology', 951, 'DIGITAL URINARY FLOW METER', '3F3445', 'M02URIFLOW-URO', 'PICO FLOW2\r\n', 'MEDICA', NULL, 'MEDICA', NULL, 'A', '$40000', '2019-07-04', '2023-07-04', 'Y'),
('Urology', 950, 'DIGITAL URINARY FLOW METER', '3F3476', 'M01URIFLOW-URO', 'PICO FLOW2\r\n', 'MEDICA', NULL, 'MEDICA', NULL, 'A', '$40000', '2019-07-04', '2023-07-04', 'Y'),
('IP', 251, 'SPHYGMOMANOMETER', '420601SP01', 'M06MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '7000', '2018-03-05', '2021-04-05', 'N'),
('IP', 250, 'SPHYGMOMANOMETER', '420601SP05', 'M01MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '6000', '2017-04-05', '2020-04-05', 'N'),
('IP', 250, 'SPHYGMOMANOMETER', '420605SP05', 'M02MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '6000', '2017-04-05', '2020-04-05', 'N'),
('IP', 250, 'SPHYGMOMANOMETER', '420610SP05', 'M03MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '6000', '2017-04-05', '2020-04-05', 'N'),
('IP', 250, 'SPHYGMOMANOMETER', '420615SP05', 'M04MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '6000', '2017-04-05', '2017-04-05', 'N'),
('IP', 251, 'SPHYGMOMANOMETER', '420620SP01', 'M07MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '7000', '2018-03-05', '2021-04-05', 'N'),
('IP', 250, 'SPHYGMOMANOMETER', '420620SP05', 'M05MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '6000', '2017-04-05', '2020-04-05', 'N'),
('IP', 251, 'SPHYGMOMANOMETER', '420625SP05', 'M08MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '7000', '2018-03-05', '2021-04-05', 'N'),
('IP', 251, 'SPHYGMOMANOMETER', '420630SP05', 'M09MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '7000', '2018-03-05', '2021-04-05', 'N'),
('IP', 251, 'SPHYGMOMANOMETER', '420635SP05', 'M10MANOMETER-IP', 'SMD-420601', 'SUNMED', 'NULL', 'ELFATH', 'NULL', 'A', '7000', '2018-03-05', '2021-04-05', 'N'),
('Otolaryngology', 920, 'OTOSCOPE', '45233D45', 'M01SCOPE-OTO', '01.13500.021', 'KaWe - KIRCHNER & WILHELM', NULL, 'Alcan medical', NULL, 'A', '2000', '2019-11-04', NULL, 'N'),
('Otolaryngology', 920, 'PHARYNGOSCOPE', '4536Q1', 'M01PHARSCOPE-OTO', 'EFL 11-20-30/40', 'EndoMed Systems ', NULL, 'ELFATH', NULL, 'A', '4500', '2020-01-26', NULL, 'N'),
('Otolaryngology', 921, 'PHARYNGOSCOPE', '4536Y3', 'M02PHARSCOPE-OTO', 'EFL 11-20-30/40', 'EndoMed Systems ', NULL, 'ELFATH', NULL, 'A', '4500', '2020-01-16', NULL, 'N'),
('Otolaryngology', 921, 'OTOSCOPE', '45773D45', 'M02SCOPE-OTO', '01.13500.021', 'KaWe - KIRCHNER & WILHELM', NULL, 'Alcan medical', NULL, 'A', '2000', '2019-11-04', NULL, 'N'),
('ICU', 102, 'INFUSION-PUMP', '48VUTT95', 'ICU14IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6700', '2020-04-12', NULL, 'N'),
('ICU', 101, 'INFUSION-PUMP', '491UTT70', 'ICU04IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6000', '2019-11-12', NULL, 'Y'),
('Urology', 951, 'CYSTO-RESECTOSCOPE / STRAIGHT', '4hd63', 'M02CYSTO-URO', '630-235-10B', 'EMED', NULL, 'ELFATH', NULL, 'A', '25000', '2019-11-10', '2025-11-10', 'N'),
('Urology', 950, 'CYSTO-RESECTOSCOPE / STRAIGHT', '4hd67', 'M01CYSTO-URO', '630-235-10B', 'EMED', NULL, 'ELFATH', NULL, 'A', '25000', '2019-11-10', '2025-11-10', 'N'),
('Laboratory', 751, 'LABORATORY VACUUM PUMP', '52GS72S2', 'M02VACPUMP-LAB', 'GM-0.20', 'Biobase', NULL, 'Alcan medical', NULL, 'A', '2500', '2019-01-20', '2020-01-20', 'N'),
('Laboratory', 750, 'LABORATORY VACUUM PUMP', '52GS72U8', 'M01VACPUMP-LAB', 'GM-0.20', 'Biobase', NULL, 'Alcan medical', NULL, 'A', '2500', '2019-01-20', '2020-01-20', 'N'),
('Urology', 951, 'INTRACORPOREAL LITHOTRIPTER ', '563289F46G', 'M02INTRALITHO-URO', 'INTRALITH ULTRA', 'US Healthcare solutions', NULL, 'Alcan medical', NULL, 'A', '$50000', '2010-11-10', '2013-11-10', 'N'),
('Urology', 950, 'INTRACORPOREAL LITHOTRIPTER ', '567489F46G', 'M01INTRALITHO-URO', 'INTRALITH ULTRA', 'US Healthcare solutions', NULL, 'Alcan medical', NULL, 'A', '$50000', '2010-11-10', '2013-11-10', 'N'),
('ICU', 101, 'INFUSION-PUMP', '591UTT70', 'ICU05IP', 'UT600II', 'UTTS-Healthcare', NULL, 'ELFATH', NULL, 'A', '6000', '2019-11-12', NULL, 'Y'),
('IP', 250, 'MONITOR', '600PLM7', 'M01MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '15000', '2017-04-30', '2021-04-30', 'Y'),
('Laboratory', 751, 'FORCED CONVECTION LABORATORY INCUBATOR', '627GD22', 'M02FORCINCU-LAB', 'HETTCUBE 400 | 400 R', 'Andreas HETTICH GmbH & Co.KG', NULL, 'Alcan medical', NULL, 'A', '15000', '2019-04-03', '2024-04-03', 'Y'),
('Laboratory', 750, 'FORCED CONVECTION LABORATORY INCUBATOR', '627GD52', 'M01FORCINCU-LAB', 'HETTCUBE 400 | 400 R', 'Andreas HETTICH GmbH & Co.KG', NULL, 'Alcan medical', NULL, 'A', '15000', '2019-01-20', '2024-01-20', 'Y'),
('Laboratory', 750, 'DIGITAL HOTPLATE ', '65366328', 'NM01HOTPLATE-LAB', 'SSH-D SERIES\r\n', 'Biobase', NULL, 'Alcan medical', NULL, 'A', '3000', '2018-03-10', '2020-03-10', 'N'),
('Laboratory', 751, 'MATRIX PRINTER', '67847720', 'NM02PRINTER-LAB', '911-013', 'KERN & SOHN', NULL, 'Alcan medical', NULL, 'A', '350', '2018-03-10', '2019-03-10', 'N'),
('Laboratory', 750, 'MATRIX PRINTER', '67847738', 'NM01PRINTER-LAB', '911-013', 'KERN & SOHN', '', 'Alcan medical', NULL, 'A', '350', '2018-03-10', '2019-01-30', 'N'),
('IP', 250, 'MONITOR', '700PLM5', 'M02MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '15000', '2017-04-30', '2021-04-30', 'Y'),
('Laboratory', 750, 'LABORATORY CENTRIFUGE', '736419', 'M01CENTRIFUGE-LAB', 'HICEN GR', 'Herolab GmbH Laborgeräte', NULL, 'Alcan medical', NULL, 'A', '4500', '2017-10-10', '2020-10-10', 'N'),
('Laboratory', 751, 'LABORATORY CENTRIFUGE', '736429', 'M02CENTRIFUGE-LAB', 'HICEN GR', 'Herolab GmbH Laborgeräte', NULL, 'Alcan medical', NULL, 'A', '4500', '2017-10-10', '2020-10-10', 'N'),
('ICU', 100, 'ECG-MONITOR', '7XL151IF', 'ICU01MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 100, 'ECG-MONITOR', '7XL152IF', 'ICU02MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 100, 'ECG-MONITOR', '7XL153IF', 'ICU03MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 100, 'ECG-MONITOR', '7XL154IF', 'ICU04MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 100, 'ECG-MONITOR', '7XL155IF', 'ICU05MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 101, 'ECG-MONITOR', '7XL156IF', 'ICU06MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 101, 'ECG-MONITOR', '7XL157IF', 'ICU07MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 101, 'ECG-MONITOR', '7XL158IF', 'ICU08MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 101, 'ECG-MONITOR', '7XL159IF', 'ICU09MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ELFATH', NULL, 'A', '45000', '2019-10-14', '2022-10-13', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL231IF', 'ICU11MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL232IF', 'ICU12MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL233IF', 'ICU13MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL234IF', 'ICU14MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL235IF', 'ICU15MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL236IF', 'ICU16MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('ICU', 102, 'ECG-MONITOR', '7XL237IF', 'ICU17MT', 'INFINITY-DELTA', 'Dräger\r\n', NULL, 'ALcan-Medic', NULL, 'A', '43500', '2020-04-22', '2023-05-21', 'N'),
('Laboratory', 750, 'CLEAN ROOM / MODULAR', '7Y528J9', 'M01CLEANROOM-LAB', 'STERIS FINN-AQUA ', 'STERIS', NULL, 'Alcan medical', NULL, 'A', '65000', '2019-02-10', '2025-02-10', 'Y'),
('Laboratory', 751, 'CLEAN ROOM / MODULAR', '7Y538J9', 'M02CLEANROOM-LAB', 'STERIS FINN-AQUA ', 'STERIS', NULL, 'Alcan medical', NULL, 'A', '65000', '2019-03-20', '2025-03-20', 'Y'),
('ICU', 102, 'SYRINGE-PUMP', '800NE5LN', 'ICU11SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '5800', '2020-03-21', '2022-08-21', 'Y'),
('IP', 250, 'MONITOR', '800PLM3', 'M03MONITOR-IP', '12.INCH', 'TOPINTH', 'NULL', 'Alcan Medical', 'NULL', 'A', '15000', '2017-04-30', '2021-04-30', 'Y'),
('ICU', 100, 'BLOOD-FRIDGE', '805INH10', 'ICU01BF', 'MBC-4V100', 'METHER', NULL, 'ELFATH', NULL, 'B', '70000', '2020-04-01', NULL, 'N'),
('ICU', 101, 'BLOOD-FRIDGE', '805INH20', 'ICU02BF', 'MBC-4V100', 'METHER', NULL, 'ELFATH', NULL, 'B', '70000', '2020-04-01', NULL, 'N'),
('ICU', 102, 'BLOOD-FRIDGE', '805INH25', 'ICU11BF', 'MBC-4V100', 'METHER', NULL, 'ELFATH', NULL, 'B', '70000', '2020-04-01', NULL, 'N'),
('ICU', 100, 'SYRINGE-PUMP', '815NE5LL', 'ICU01SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'B', '5400', '2019-12-06', '2021-11-30', 'Y'),
('ICU', 102, 'SYRINGE-PUMP', '820NE5LN', 'ICU12SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '5800', '2020-03-21', '2022-08-21', 'Y'),
('ICU', 100, 'SYRINGE-PUMP', '825NE5LL', 'ICU02SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'B', '5400', '2019-12-06', '2021-11-30', 'Y'),
('ICU', 102, 'SYRINGE-PUMP', '830NE5LN', 'ICU13SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '5800', '2020-03-21', '2022-08-21', 'Y'),
('ICU', 100, 'SYRINGE-PUMP', '835NE5LL', 'ICU03SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'B', '5400', '2019-12-06', '2021-11-30', 'Y'),
('ICU', 102, 'SYRINGE-PUMP', '840NE5LN', 'ICU14SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '5800', '2020-03-21', '2022-08-21', 'Y'),
('ICU', 101, 'SYRINGE-PUMP', '845NE5LL', 'ICU04SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'B', '5400', '2019-12-06', '2021-11-30', 'Y'),
('ICU', 101, 'SYRINGE-PUMP', '855NE5LL', 'ICU05SP', 'NE500', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'B', '5400', '2019-12-06', '2021-11-30', 'Y'),
('Urology', 951, 'COMPUTER-BASED URODYNAMIC SYSTEM / ON CASTERS', '87JF9', 'M02DYNSYS-URO', 'PICO SMART', 'MEDICA', NULL, 'MEDICA', NULL, 'A', '$70000', '2019-11-20', NULL, 'Y'),
('Urology', 950, 'COMPUTER-BASED URODYNAMIC SYSTEM / ON CASTERS', '87JJ8', 'M01DYNSYS-URO', 'PICO SMART', 'MEDICA', NULL, 'MEDICA', NULL, 'A', '$70000', '2019-10-16', NULL, 'Y'),
('IP', 250, 'MONITOR', '900PLM9', 'M04MONITOR-IP', '12.INCH', 'TOPINTH', 'NULL', 'Alcan Medical', 'NULL', 'A', '15000', '2017-04-30', '2021-04-30', 'Y'),
('IP', 250, 'MONITOR', '966PLM96', 'M05MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '15000', '2017-04-30', '2021-04-30', 'Y'),
('IP', 251, 'MONITOR', '967PLM96', 'M06MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '20000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'MONITOR', '968PLM96', 'M07MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '20000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'MONITOR', '969PLM96', 'M08MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '20000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'MONITOR', '971PLM96', 'M10MONITOR-IP', '12.INCH', 'TOPNITH', 'NULL', 'Alcan Medical', 'NULL', 'A', '20000', '2018-03-05', '2022-03-05', 'Y'),
('Otolaryngology', 921, 'SINUSCOPE ', 'AH25D7J', 'M02SINU-OTO', 'RIGID HD', 'OLYMPUS', NULL, 'Alcan medical', NULL, 'A', '6000', '2018-06-15', '2020-06-15', 'N'),
('Otolaryngology', 920, 'SINUSCOPE ', 'AH25DW2', 'M01SINU-OTO', 'RIGID HD', 'OLYMPUS', NULL, 'Alcan medical', NULL, 'A', '6000', '2018-06-15', '2022-06-15', 'N'),
('Orthopedics', 880, 'DRILL SURGICAL POWER TOOL', 'AHG3265S', 'M01DRILL-ORTHO', 'MBQ-700 SERIES', 'DeSoutter Medical', NULL, 'DeSoutter Medical', NULL, 'A', '23000', '2018-04-23', '2020-04-23', 'N'),
('Orthopedics', 881, 'DRILL SURGICAL POWER TOOL', 'AHG9965S', 'M02DRILL-ORTHO', 'MBQ-700 SERIES', 'DeSoutter Medical', NULL, 'DeSoutter Medical', NULL, 'A', '23000', '2015-10-12', NULL, 'N'),
('Anesthesiology', 500, 'Mindray Anaesthesia Machine', 'anZww22', 'M01ANES-ANESTH', '\r\nPAS-200C', 'Poweam', NULL, 'ELFATH', NULL, 'A', '78000', '2017-04-14', '2019-04-14', 'Y'),
('Anesthesiology', 501, 'Mindray Anaesthesia Machine', 'azZwq32', 'M02ANES-ANESTH', 'PAS-200C', 'Poweam', NULL, 'ELFATH', NULL, 'A', '78000', '2017-04-14', '2019-04-14', 'Y'),
('CSSD', 600, 'MEDICAL STERILIZER / CSSD / STEAM', 'c22ss11d', 'M01STEAM-CSSD', 'SQ-Z', 'SANQIANG', NULL, 'medik', NULL, 'A', '90000', '2020-04-29', '2021-04-29', 'Y'),
('CSSD', 601, 'MEDICAL STERILIZER / CSSD / STEAM', 'c23ss00d', 'M02STEAMST-CSSD', 'SQ-Z', '	\r\nSANQIANG', NULL, 'medik', NULL, 'A', '90000', '2020-04-30', '2021-04-30', 'Y'),
('CSSD', 600, 'Laboratory Autoclave', 'ca11223', 'M01AUTOCAVE-CSSD', 'BKQ-B50(II)', 'BIOBASE', NULL, 'medik', NULL, 'A', '3000', '2019-11-11', '2020-11-11', 'N'),
('CSSD', 601, 'Laboratory Autoclave', 'ca11277', 'M02AUTOCAVE-CSSD', 'BKQ-B50(II)', 'BIOBASE', NULL, 'medik', NULL, 'A', '3000', '2019-10-04', '2020-10-04', 'N'),
('IP', 250, 'WEIGHING-SCALE', 'DEG10009M', 'M02SCALE-IP', 'DIGITAL-SCALE', 'FRK', 'NULL', 'ELFATH', 'NULL', 'A', '2000', '2017-05-05', '2019-05-05', 'Y'),
('IP', 251, 'WEIGHING-SCALE', 'DEG10010M', 'M03SCALE-IP', 'DIGITAL-SCALE', 'FRK', 'NULL', 'ELFATH', 'NULL', 'A', '2500', '2018-03-05', '2020-03-05', 'Y'),
('IP', 251, 'WEIGHING-SCALE', 'DEG10910M', 'M04SCALE-IP', 'DIGITAL-SCALE', 'FRK', 'NULL', 'ELFATH', 'NULL', 'A', '2500', '2018-03-05', '2020-03-05', 'Y'),
('IP', 250, 'WEIGHING-SCALE', 'DEG20019L', 'M01SCALE-IP', 'DIGITAL-SCALE', 'FRK', 'NULL', 'ELFATH', 'NULL', 'A', '2000', '2017-05-05', '2019-05-05', 'Y'),
('ICU', 100, 'DEFIBRILLATOR', 'DF861CZ', 'ICU01DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '48500', '2019-07-14', '2022-10-28', 'Y'),
('ICU', 100, 'DEFIBRILLATOR', 'DF862CZ', 'ICU02DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '48500', '2019-07-14', '2022-10-28', 'Y'),
('ICU', 100, 'DEFIBRILLATOR', 'DF863CZ', 'ICU03DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '48500', '2019-07-14', '2022-10-28', 'Y'),
('ICU', 101, 'DEFIBRILLATOR', 'DF864CZ', 'ICU04DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '48500', '2019-07-14', '2022-10-28', 'Y'),
('ICU', 101, 'DEFIBRILLATOR', 'DF865CZ', 'ICU05DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '48500', '2019-07-14', '2022-10-28', 'Y'),
('ICU', 102, 'DEFIBRILLATOR', 'DF871AN', 'ICU11DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '50000', '2019-08-16', '2022-11-18', 'Y'),
('ICU', 102, 'DEFIBRILLATOR', 'DF872AN', 'ICU12DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '50000', '2019-08-16', '2022-11-18', 'Y'),
('ICU', 102, 'DEFIBRILLATOR', 'DF873AN', 'ICU13DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '50000', '2019-08-16', '2022-11-18', 'Y'),
('ICU', 102, 'DEFIBRILLATOR', 'DF874AN', 'ICU14DF', 'DEFI-8', 'MEDI-TECH', NULL, 'ALcan-Medic', NULL, 'A', '50000', '2019-08-16', '2022-11-18', 'Y'),
('ICU', 102, 'ICU-BED', 'DS361Z3', 'ICU11BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS362Z3', 'ICU12BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS363Z3', 'ICU13BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS364Z3', 'ICU14BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS365Z3', 'ICU15BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS366Z3', 'ICU16BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 102, 'ICU-BED', 'DS367Z3', 'ICU17BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '21500', '2020-02-08', NULL, 'N'),
('ICU', 100, 'ICU-BED', 'DS912C1', 'ICU01BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 100, 'ICU-BED', 'DS922C1', 'ICU02BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 100, 'ICU-BED', 'DS932C1', 'ICU03BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 100, 'ICU-BED', 'DS942C1', 'ICU04BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 100, 'ICU-BED', 'DS952C1', 'ICU05BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 101, 'ICU-BED', 'DS962C1', 'ICU06BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 101, 'ICU-BED', 'DS972C1', 'ICU07BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 101, 'ICU-BED', 'DS982C1', 'ICU08BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('ICU', 101, 'ICU-BED', 'DS992C1', 'ICU09BD', 'DSD-electric_bed', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '20000', '2020-03-22', NULL, 'Y'),
('Orthopedics', 881, 'ARTHROSCOPY SHAVER', 'DWD323E', 'M02SHAVER-ORTHO', 'SV-8002', 'Vimex Endoscopy ', NULL, 'Alcan medical', NULL, 'A', '25000', '2019-04-19', '2023-04-19', 'N'),
('Orthopedics', 880, 'ARTHROSCOPY SHAVER', 'DWD3F5Y', 'M01SHAVER-ORTHO', 'SV-8002', 'Vimex Endoscopy ', NULL, 'Alcan medical', NULL, 'A', '25000', '2019-07-04', '2023-07-04', 'N'),
('Orthopedics', 880, 'ELECTRIC MENISCAL RASP', 'GD52BS7', 'M01RASP-ORTHO', 'OMNISPAN™', 'DePuySynthes', NULL, 'ELFATH', NULL, 'A', '15000', '2018-03-08', NULL, 'N'),
('Laboratory', 750, 'TYPE A2 BIOLOGICAL SAFETY CABINET ', 'GE52J722', 'M01BIOCABINET-LAB', '11231BBC86\r\n', 'Biobase', NULL, 'ELFATH', NULL, 'A', '25000', '2010-01-20', '2014-01-20', 'N'),
('Laboratory', 751, 'BIOLOGICAL SAFETY CABINET,TYPE A2 ', 'GE52J744', 'M02BIOCABINET-LAB', '11231BBC86', 'Biobase', NULL, 'ELFATH', NULL, 'A', '25000', '2010-01-30', '2014-01-30', 'N'),
('Laboratory', 750, 'LABORATORY PERISTALTIC PUMP', 'H62382JS', 'M01PERISTPUMP-LAB', 'DPP-F6 SERIES\r\n', 'Biobase', NULL, 'Alcan medical', NULL, 'A', '4500', '2018-10-30', '2020-10-30', 'Y'),
('Orthopedics', 881, 'ELECTRIC CAST SAW ', 'H62N8022', 'M02CASTSAW-ORTHO', 'CC5', 'DeSoutter Medical', NULL, 'DeSoutter Medical', NULL, 'A', '20000', '2017-04-19', '2020-04-14', 'N'),
('Orthopedics', 880, 'ELECTRIC CAST SAW ', 'H62N802J', 'M01CASTSAW-ORTHO', 'CC5', 'DeSoutter Medical', NULL, 'DeSoutter Medical', NULL, 'A', '20000', '2017-04-19', '2020-04-14', 'N'),
('Laboratory', 750, 'LABORATORY FREEZER', 'HD63H829', 'M01FREEZER-LAB', 'F130', 'B Medical Systems ', NULL, 'ELFATH', NULL, 'A', '40000', '2018-03-10', '2022-03-10', 'N'),
('Orthopedics', 880, 'SURGERY ORTHOPEDIC EXTENSION DEVICE', 'HWY62GD', 'M01SURGERYBED-ORTHO', '9923046', 'OPT SurgiSystems', NULL, 'Alcan medical', NULL, 'A', '16000', '2017-04-19', '2021-04-19', 'N'),
('Orthopedics', 881, 'SURGERY ORTHOPEDIC EXTENSION DEVICE', 'HWY65GD', 'M02SURGERYBED-ORTHO', '9923046', 'OPT SurgiSystems', NULL, 'Alcan medical', NULL, 'A', '16000', '2017-04-19', '2021-04-19', 'N'),
('Laboratory', 750, 'PCR CABINET ', 'K637FAA2', 'M01PCR-LAB', 'UVP PCR UV³', 'Analytikajena', NULL, 'EGA-TECH', NULL, 'A', '35000', '2017-08-02', '2019-09-20', 'N'),
('Laboratory', 751, 'PCR CABINET ', 'K637FAA7', 'M02PCR-LAB', 'UVP PCR UV³', 'Analytikajena', NULL, 'EGA-TECH', NULL, 'A', '35000', '2017-06-23', '2021-04-09', 'N'),
('ICU', 102, 'PULSE-OXIMETER', 'N521KX4', 'ICU11PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N522KX4', 'ICU12PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N523KX4', 'ICU13PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N524KX4', 'ICU14PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N525KX4', 'ICU15PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N526KX4', 'ICU16PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('ICU', 102, 'PULSE-OXIMETER', 'N527KX4', 'ICU17PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '5000', '2019-09-24', NULL, 'Y'),
('OP', 150, 'PULSE-OXIMETER', 'N541VT4', 'OP501PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('OP', 150, 'PULSE-OXIMETER', 'N542VT4', 'OP502PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('OP', 150, 'PULSE-OXIMETER', 'N543VT4', 'OP503PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('OP', 151, 'PULSE-OXIMETER', 'N544VT4', 'OP511PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('OP', 151, 'PULSE-OXIMETER', 'N545VT4', 'OP512PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('OP', 151, 'PULSE-OXIMETER', 'N546VT4', 'OP516PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'B', '5200', '2018-12-24', NULL, 'Y'),
('ICU', 100, 'PULSE-OXIMETER', 'N581KM9', 'ICU01PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 100, 'PULSE-OXIMETER', 'N582KM9', 'ICU02PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 100, 'PULSE-OXIMETER', 'N583KM9', 'ICU03PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 100, 'PULSE-OXIMETER', 'N584KM9', 'ICU04PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 100, 'PULSE-OXIMETER', 'N585KM9', 'ICU05PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 101, 'PULSE-OXIMETER', 'N586KM9', 'ICU06PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 101, 'PULSE-OXIMETER', 'N587KM9', 'ICU07PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 101, 'PULSE-OXIMETER', 'N588KM9', 'ICU08PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('ICU', 101, 'PULSE-OXIMETER', 'N589KM9', 'ICU09PO', 'N-595', 'NELLCOR', NULL, 'ELFATH', NULL, 'A', '4500', '2019-07-22', NULL, 'Y'),
('IP', 250, 'VENTILLATORS', 'O800VVX1', 'M01VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '624000', '2017-07-10', '2021-06-10', 'Y'),
('IP', 251, 'VENTILLATORS', 'O800VVX11', 'M06VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '627000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'VENTILLATORS', 'O800VVX15', 'M07VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '627000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'VENTILLATORS', 'O800VVX17', 'M08VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '627000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 251, 'VENTILLATORS', 'O800VVX19', 'M09VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '627000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 250, 'VENTILLATORS', 'O800VVX20', 'M03VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '624000', '2017-07-10', '2021-06-10', 'Y'),
('IP', 251, 'VENTILLATORS', 'O800VVX21', 'M10VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '627000', '2018-03-05', '2022-03-05', 'Y'),
('IP', 250, 'VENTILLATORS', 'O800VVX3', 'M04VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '624000', '2017-07-10', '2021-06-10', 'Y'),
('IP', 250, 'VENTILLATORS', 'O800VVX5', 'M02VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '624000', '2017-07-10', '2021-06-10', 'Y'),
('IP', 250, 'VENTILLATORS', 'O800VVX9', 'M05VENT-IP', 'ACM812A', 'ACM', 'NULL', 'Alcan Medical', 'NULL', 'A', '624000', '2017-07-10', '2021-06-10', 'Y'),
('IP', 250, 'TROLLEY', 'P5150YA', 'M03TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4000', '2017-06-10', '2025-06-10', 'N'),
('IP', 250, 'TROLLEY', 'P5200YA', 'M04TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4000', '2017-06-10', '2025-06-10', 'N'),
('IP', 251, 'TROLLEY', 'P5215YA', 'M07TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4700', '2018-03-10', '2026-03-10', 'N'),
('IP', 251, 'TROLLEY', 'P5220YA', 'M08TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4700', '2018-03-10', '2026-03-10', 'N'),
('IP', 251, 'TROLLEY', 'P5230YA', 'M09TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4700', '2018-03-10', '2026-03-10', 'N'),
('IP', 251, 'TROLLEY', 'P52500YA', 'M10TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4700', '2018-03-10', '2026-03-10', 'N'),
('IP', 250, 'TROLLEY', 'P5250YA', 'M05TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4000', '2017-06-10', '2025-06-10', 'N'),
('IP', 251, 'TROLLEY', 'P5255YA', 'M06TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4700', '2018-03-10', '2026-03-10', 'N'),
('Otolaryngology', 920, 'ENT SURGERY MICROSCOPE ', 'Q21WS2', 'M01MICROSCO-OTO', 'KAPS PRO ENT M', 'Karl Kaps ', NULL, 'ELFATH', NULL, 'A', '45000', '2013-08-05', NULL, 'N'),
('Otolaryngology', 920, 'ENT CHAIR,EXAM', 'SED232W1', 'M01CHAIR-OTO', '2683', 'Promotal', NULL, 'ELFATH', NULL, 'A', '12000', '2016-10-22', '2020-10-22', 'N'),
('Otolaryngology', 921, 'ENT CHAIR,EXAM', 'SED2341D', 'M02CHAIR-OTO', '2683', 'Promotal', NULL, 'ELFATH', NULL, 'A', '12000', '2016-10-22', '2020-10-22', 'N'),
('Anesthesiology', 500, 'laryngoscope', 'sf5G55', 'M02SCOPE-ANESTH', 'HYHJ-KC', 'HAIYE', NULL, 'midk', NULL, 'A', '7000', '2019-11-11', '2022-11-09', 'N'),
('Anesthesiology', 501, 'laryngoscope', 'sf5Gu7', 'M03SCOPE-ANESTH', 'HYHJ-KC', 'HAIYE', NULL, 'midk', NULL, 'A', '7000', '2019-11-11', '2022-11-09', 'N'),
('ICU', 102, 'SUCTION-MACHINE', 'SK107EX', 'ICU11SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 100, 'SUCTION-MACHINE', 'SK168EX', 'ICU01SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 102, 'SUCTION-MACHINE', 'SK207EX', 'ICU12SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 100, 'SUCTION-MACHINE', 'SK268EX', 'ICU02SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 102, 'SUCTION-MACHINE', 'SK307EX', 'ICU13SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 100, 'SUCTION-MACHINE', 'SK368EX', 'ICU03SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 102, 'SUCTION-MACHINE', 'SK407EX', 'ICU14SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 101, 'SUCTION-MACHINE', 'SK468EX', 'ICU04SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('ICU', 101, 'SUCTION-MACHINE', 'SK568EX', 'ICU05SM', 'SK-EX102', 'SAIKANG', NULL, 'ALcan-Medic', NULL, 'A', '3000', '2019-12-12', NULL, 'Y'),
('Anesthesiology', 500, 'laryngoscope', 'ss4G55', 'M01SCOPE-ANESTH', 'HYHJ-KC', 'HAIYE', NULL, 'midk', NULL, 'A', '7000', '2019-11-09', '2022-11-09', 'N'),
('ICU', 100, 'VENTILATOR', 'VN-101-SI18', 'ICU01VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 100, 'VENTILATOR', 'VN-102-SI18', 'ICU02VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 100, 'VENTILATOR', 'VN-103-SI18', 'ICU03VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 100, 'VENTILATOR', 'VN-104-SI18', 'ICU04VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 100, 'VENTILATOR', 'VN-105-SI18', 'ICU05VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 101, 'VENTILATOR', 'VN-106-SI18', 'ICU06VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 101, 'VENTILATOR', 'VN-107-SI18', 'ICU07VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 101, 'VENTILATOR', 'VN-108-SI18', 'ICU08VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 101, 'VENTILATOR', 'VN-109-SI18', 'ICU09VN', 'Siaretron-4000', 'SIARE', NULL, 'ELFFATH', NULL, 'A', '80000', '2019-10-14', '2024-10-13', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-721-SI20', 'ICU11VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-722-SI20', 'ICU12VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-723-SI20', 'ICU13VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-724-SI20', 'ICU14VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-725-SI20', 'ICU15VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-726-SI20', 'ICU16VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('ICU', 102, 'VENTILATOR', 'VN-727-SI20', 'ICU17VN', 'Siaretron-4000', 'SIARE', NULL, 'ALcan Medical', NULL, 'A', '82000', '2020-04-22', '2025-05-21', 'Y'),
('Laboratory', 751, 'LABORATORY COLD ROOM', 'Y3672G269', 'M02COLDROOM-LAB', 'JSSC-700C', 'JSR', NULL, 'Alcan medical', NULL, 'A', '100000', '2019-09-20', '2024-09-20', 'Y'),
('Laboratory', 750, 'LABORATORY COLD ROOM', 'Y3672G278', 'M01COLDROOM-LAB', 'JSSC-700C', 'JSR', NULL, 'Alcan medical', NULL, 'A', '100000', '2019-10-20', '2024-10-20', 'Y'),
('IP', 250, 'TROLLEY', 'Y5000PA', 'M01TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4000', '2017-06-10', '2025-06-10', 'N'),
('IP', 250, 'TROLLEY', 'Y5100PA', 'M02TROLLEY-IP', 'AG-MT001A1', 'AEGEA', 'NULL', 'ELFATH', 'NULL', 'A', '4000', '2017-06-10', '2025-06-10', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `ppm`
--

CREATE TABLE IF NOT EXISTS `ppm` (
  `department` varchar(200) NOT NULL,
  `department_code` int(100) NOT NULL,
  `nomenclature` varchar(200) NOT NULL,
  `ppm_id` varchar(200) NOT NULL,
  `time_period` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `assigned_to` varchar(200) NOT NULL,
  `ppm_task` varchar(200) NOT NULL,
  `contract_id` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ppm`
--

INSERT INTO `ppm` (`department`, `department_code`, `nomenclature`, `ppm_id`, `time_period`, `from_date`, `to_date`, `assigned_to`, `ppm_task`, `contract_id`, `status`) VALUES
('ICU', 100, 'Ultrasound Unit', 'icu01ultras', '0000-00-00', '2019-05-10', '2019-05-11', 'mohamed ahmed', 'check propes , modes cables,port', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `department` varchar(200) NOT NULL,
  `de_code` int(100) NOT NULL,
  `equip_name` varchar(200) NOT NULL,
  `manufacturer` varchar(200) NOT NULL,
  `model` varchar(200) NOT NULL,
  `fault_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `priority` int(100) NOT NULL,
  `fault_description` varchar(200) NOT NULL,
  `job_no` int(100) NOT NULL,
  `tech_name` varchar(200) NOT NULL,
  `action_taken` varchar(200) NOT NULL,
  `solved` varchar(200) NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `report_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`department`, `de_code`, `equip_name`, `manufacturer`, `model`, `fault_date`, `priority`, `fault_description`, `job_no`, `tech_name`, `action_taken`, `solved`, `end_date`, `report_id`) VALUES
('ICU', 100, 'Ultrasound Unit', 'GE', '	\r\nVivid S5', '2020-01-03 05:14:00', 4, 'linear array prope defect', 2033, 'maher mohamed', 'sent a report to the company', 'yes', '2020-04-05 08:05:00', 'icu01ultras');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE IF NOT EXISTS `store` (
  `nomenclature` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `model` varchar(200) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `manufacturer` varchar(200) NOT NULL,
  `local_agent` varchar(200) NOT NULL,
  `warrenty_period` varchar(200) NOT NULL,
  `stop_production_date` date DEFAULT NULL,
  `end_support_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`nomenclature`, `serial_no`, `model`, `manufacturer`, `local_agent`, `warrenty_period`, `stop_production_date`, `end_support_date`) VALUES
('Ultrasound Unit', '0504154G6', 'Vivid S5', 'GE', 'Alcan medical', '2 years', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calibration`
--
ALTER TABLE `calibration`
  ADD KEY `calibration_ibfk_1` (`cal_id`),
  ADD KEY `calibration_ibfk_2` (`dcode`);

--
-- Indexes for table `daily_inspection`
--
ALTER TABLE `daily_inspection`
  ADD KEY `id` (`dinspect_id`),
  ADD KEY `daily_inspection_ibfk_2` (`d_code`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`national_id`),
  ADD KEY `depart_code` (`depart_code`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`serial_no`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `dep_code` (`dep_code`);

--
-- Indexes for table `ppm`
--
ALTER TABLE `ppm`
  ADD KEY `id` (`ppm_id`),
  ADD KEY `department_code` (`department_code`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD KEY `reports_ibfk_2` (`de_code`),
  ADD KEY `id` (`report_id`) USING BTREE;

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`serial_no`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `calibration`
--
ALTER TABLE `calibration`
  ADD CONSTRAINT `calibration_ibfk_1` FOREIGN KEY (`cal_id`) REFERENCES `equipment` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `calibration_ibfk_2` FOREIGN KEY (`dcode`) REFERENCES `department` (`code`) ON UPDATE NO ACTION;

--
-- Constraints for table `daily_inspection`
--
ALTER TABLE `daily_inspection`
  ADD CONSTRAINT `daily_inspection_ibfk_1` FOREIGN KEY (`dinspect_id`) REFERENCES `equipment` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `daily_inspection_ibfk_2` FOREIGN KEY (`d_code`) REFERENCES `department` (`code`) ON UPDATE NO ACTION;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`depart_code`) REFERENCES `department` (`code`);

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`dep_code`) REFERENCES `department` (`code`);

--
-- Constraints for table `ppm`
--
ALTER TABLE `ppm`
  ADD CONSTRAINT `ppm_ibfk_1` FOREIGN KEY (`ppm_id`) REFERENCES `equipment` (`id`),
  ADD CONSTRAINT `ppm_ibfk_2` FOREIGN KEY (`department_code`) REFERENCES `department` (`code`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `equipment` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`de_code`) REFERENCES `department` (`code`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
